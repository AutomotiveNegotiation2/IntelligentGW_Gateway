#!/bin/bash

python3 Voxelization_compression.py --voxel_size 0.12