# How to build
$> build.sh


# How to Test
$> ./test_aes_ctr

Encrypted msg: 63ec4ed1ea8f293e8d49ff5ccf312e2b5de7f9cbff7b35
Decrypted msg: 0505050505050505050505050505050505050505050505
