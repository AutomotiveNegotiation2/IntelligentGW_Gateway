// aursa.h

/** Only use in library source file */

#ifndef _AURSA_H_
#define _AURSA_H_

#include <stdint.h>
#include "aursatype.h"

extern void Run_CyRng(uint8_t* output, uint32_t sz);

#endif
