/* Base Include */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <time.h>
#include <fcntl.h>
#include <sys/types.h>

#include <stdarg.h>

/* Util IPV4_Task */
#include <sys/ioctl.h>
#include <linux/socket.h>
#include <netinet/tcp.h>
#include <sys/socket.h>

#include <./memory_allocation_include.h>
#include <./memory_allocation_api.h>
#include <./memory_allocation_param.h>

#define NOT_CODE_FINISH 0

#define MAX_CLIENT_SIZE 128
#define DeviceName "eth0"

struct clients_info_t
{
    pthread_mutex_t mtx;
    int connected_client_num;
    int socket[MAX_CLIENT_SIZE];
    uint32_t socket_message_seq[MAX_CLIENT_SIZE];
    
    enum job_type_e socket_job_state[MAX_CLIENT_SIZE];
    struct client_data_info_t client_data_info[MAX_CLIENT_SIZE];
};

struct ticktimer_t
{
    uint32_t G_10ms_Tick;
    uint32_t G_100ms_Tick;
    uint32_t G_1000ms_Tick;
    pthread_t Th_TickTimer;
};

extern struct ticktimer_t G_TickTimer;
extern struct clients_info_t G_Clients_Info;

struct socket_info_t
{
    //Sokket_Info
    enum socket_type_e Socket_Type;
    int Socket;
    char *Device_Name;
    char Device_IPv4_Address[40];
    int Port;
    struct sockaddr_in Socket_Addr;

    pthread_t th_Task_ID;
};


extern struct socket_info_t F_s_RelayServer_TcpIp_Initial_Server(char *Device_Name, int *Port, int *err);
extern int F_i_RelayServer_TcpIp_Get_Address(chat *Device_Name, char Output_IPv4Adrress[40]);
extern int F_i_RelayServer_TcpIp_Task_Run(struct socket_info_t *Socket_Info);

static void* th_RelayServer_TcpIp_Task_Server(void *socket_info);
static int f_i_RelayServer_TcpIp_Bind(int *Server_Socket, struct sockaddr_in Socket_Addr);
static int f_i_RelayServer_TcpIp_Setup_Socket(int *Socket, int Timer, bool Linger);

//General Type Code
static int f_i_Hex2Dec(char data)
static struct data_header_t f_s_Parser_Data_Header(char *Data, size_t Data_Size);

extern void F_RealyServer_Print_Debug(enum debug_lever_e Debug_Level, const char *String, const char *format, ...);
extern void* Th_i_RelayServer_TickTimer(void *Data);



/* 
Brief:
Parameter[In]
Parameter[Out]
    socket_info_t
 */
struct socket_info_t F_s_RelayServer_TcpIp_Initial_Server(char *Device_Name, int *Port, int *err)
{
    int ret = 0;
    
    //Check Argurements
    if(!Port)
    {
        F_RealyServer_Print_Debug(0, "[Error][%s] No Input Argurements.(Server_Socket:%p, Port:%p)\n", __func__, Server_Socket, Port);
        *err = -1;
        return;
    }else{
        struct socket_info_t Socket_Info;
        Socket_Info.Socket_Type = SERVER_SOCKET;
        Socket_Info.Device_Name = Device_Name;
        Socket_Info.Port = *Port;
    }
    if(Device_Name){}
        //Getting the Ethernet Device IP Address  
        ret = F_i_RelayServer_TcpIp_Get_Address(Socket_Info.Device_Name, Socket_Info.Device_IPv4_Address);
        if(ret < 0)
        {
            F_RealyServer_Print_Debug(0,"[Error][%s] Return_Value:%d\n", __func__, ret);
            *err = -1;
            return;
        }
        Socket_Info.socket_addr.sin_addr.s_addr = inet_addr(Socket_Info.Device_IPv4_Address);
    }else
    {
        Socket_Info.socket_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    *Server_Socket = socket(AF_INET, SOCK_STREAM, 0);
    //Socket_Setup
    ret = f_i_RelayServer_TcpIp_Setup_Socket(Socket_Info.Socket, 500, true);
    if(ret < 0)
    {
        F_RealyServer_Print_Debug(0,"[Error][%s] Return_Value:%d\n", __func__, ret);
        *err = -1;
        return;
    }

    memset(&Socket_Info.socket_addr, 0x00, sizeof(Socket_Info.socket_addr));  
	Socket_Info.socket_addr.sin_family = AF_INET;  
	
	Socket_Info.socket_addr.sin_port = htons(Socket_Info.Port)

    pthread_create(&(G_TickTimer.Th_TickTimer), NULL, Th_i_RelayServer_TickTimer, NULL);

    return Socket_Info;
    
}

/* 
Brief:Getting the IPV4 address of inputed the device name.
Parameter[In]
    Device_Name:Device Name
    Output_IPv4Adrress[]:Array that size 40 to store the IPv4 address.
Parameter[Out]
    int < 0 = Error_Code
 */
int F_i_RelayServer_TcpIp_Get_Address(chat *Device_Name, char Output_IPv4Adrress[40])
{
    int ret = 0;

    //Check Argurement
    if(!Device_Name)
    {
        F_RealyServer_Print_Debug(0, "[Error][%s] No Input Argurements.(Device_Name:%p)\n", __func__, Device_Name);
        return -1;
    }

    /* Use the Ethernet Device Name to find IP Address at */
	struct ifreq ifr;
	int IP_Parsing_Socket;
    
	IP_Parsing_Socket = socket(AF_INET, SOCK_DGRAM, 0);
	strncpy(ifr.ifr_name, Device_Name, IFNAMSIZ);

	if (ioctl(IP_Parsing_Socket, SIOCGIFADDR, &ifr) < 0) {
		printf("Error");
	} else {
		inet_ntop(AF_INET, ifr.ifr_addr.sa_data+2, Output_IPv4Adrress, sizeof(struct sockaddr));
		F_RealyServer_Print_Debug(1, "[Info][%s] %s IP Address is %s\n", __func__, Device_Name, Output_IPv4Adrress);
	}
    ret = f_i_RelayServer_TcpIp_Setup_Socket(&socket, 0, true);
	close(IP_Parsing_Socket);

}
/* 
Brief:
Parameter[In]
Parameter[Out]
 */
int F_i_RelayServer_TcpIp_Task_Run(struct socket_info_t *Socket_Info)
{
    int ret;
    ret = f_i_RelayServer_TcpIp_Bind(&Socket_Info->Socket, &Socket_Info->Socket_Addr);
    if(ret < 0)
    {
            F_RealyServer_Print_Debug(0, "[Error][%s][f_i_RelayServer_TcpIp_Bind] Return Value:%d", __func__, ret);
    }else{
        pthread_t Socket_Info->th_Task_ID;
        pthread_create(&(Socket_Info->th_Task_ID), NULL, th_RelayServer_TcpIp_Task_Server, (void*)&Socket_Info);  
        pthread_detach((Socket_Info->th_Task_ID));
        F_RealyServer_Print_Debug(1, "[Sucess][%s][Task_ID:%d]\n", __func__, Socket_Info->th_Task_ID);

    }
    return 0;
}
/* 
Brief:
Parameter[In]
Parameter[Out]
 */
void *th_RelayServer_Job_Task(void *Data)
{
    Data = Data;
    struct Memory_Used_Data_Info_t *Data_Info = (struct Memory_Used_Data_Info_t*)Data;

    int ret;
    // Using_Timer
    int32_t TimerFd = timerfd_create(CLOCK_MONOTONIC, 0);
    struct itimerspec itval;
    struct timespec tv;
    uint32_t Task_Timer_Max = 1000 * 1000;
    uint32_t Task_Timer_min = 10 * 1000;
    int Task_Timer_Max
    uint64_t res;
    
    int mTime = usec / 1000;
    setsockopt(TimerFd, SOL_SOCKET, SO_RCVTIMEO, (char*)&mTime, sizeof( mTime));

    clock_gettime(CLOCK_MONOTONIC, &tv); 
    itval.it_interval.tv_sec = 0;
    itval.it_interval.tv_nsec = (Tesk_Timer_Max % 1000000) * 1e3;
    itval.it_value.tv_sec = tv.tv_sec + 1;
    itval.it_value.tv_nsec = 0;
    ret = timerfd_settime (TimerFd, TFD_TIMER_ABSTIME, &itval, NULL);

    uint32_t tick_count_10ms = 0;
    int Task_Timer_now = Task_Timer_Max;
    while(1)
    {   
        ret = read(TimerFd, &res, sizeof(res));

        if(Task_Timer_Max / 10 > Task_Timer_now - (Task_Timer_Max * (1 - (int)(*(Data_Info->Data_Count) / (MEMORY_USED_DATA_LIST_SIZE / 10)))))
        {
            Task_Timer_now = (Task_Timer_Max * (1 - (int)(*(Data_Info->Data_Count) / (MEMORY_USED_DATA_LIST_SIZE / 10))));
            clock_gettime(CLOCK_MONOTONIC, &tv); 
            itval.it_interval.tv_nsec = Task_Timer_now % 1000000) * 1e3;
            itval.it_value.tv_sec = tv.tv_sec + 1;
            timerfd_settime (TimerFd, TFD_TIMER_ABSTIME, &itval, NULL);
        }

        size_t data_size = 0;
        if(F_Memory_Data_isEmpty(Data_Info))
        {
        }else{
            uint8_t *out_data = (uint8_t*)F_v_Memory_Data_Pop(Data_Info, &data_size);
            struct data_header_t Data_Header_Info = f_s_Parser_Data_Header(out_data, HEADER_SIZE);
            if()
            for(int client_now = 0; client_now < G_Clients_Info.connected_client_num; client_now++)
            {
                if(G_Clients_Info.socket[client_now] == Data_Header_Info.Client_fd)
                {
                    switch(f_e_RelayServer_Job_Process_Do(&Data_Header_Info, out_data, client_now))
                    {
                        case JobInitial:
                        case FirmwareInfoReport:
                        case FirmwareInfoRequest:
                        case FirmwareInfoResponse:
                        case FirmwareInfoIndication:

                        case ProgramInfoReport: 
                        case ProgramInfoRequest:
                        case ProgramInfoResponse:
                        case ProgramInfoIndication:

                        case JobFinish:

                        case HandOverReminingData:
                            F_i_Memory_Data_Push(Data_Info, out_data, data_size);
                            free(out_data);
                            break;
                        default:
                            free(out_data);
                            break;
                    }
                }else
                {
                    F_i_Memory_Data_Push(Data_Info, out_data, data_size);
                    free(out_data);
                }
            }
        }
        
    }
}

struct data_header_t f_s_Parser_Data_Header(char *Data, size_t Data_Size)
{
    struct data_header_t out_data;
    int Data_Num = 0;
    for(int i = 0; i < Data_Size; i++)
    {
        if(i % 2 = 1)
        {
            switch(Data_Num)
            {
                case 0:
                    if(i = 0)
                    {
                        out_data.Job_State = (uint8_t)f_i_Hex2Dec(Data[i]);
                    }else{
                        out_data.Protocol_Type = (uint8_t)f_i_Hex2Dec(Data[i]);
                    }
                case 1:
                    out_data.Client_fd = (out_data.Client_fd * 16) + (uint16_t)f_i_Hex2Dec(Data[i]);
                case 2:
                    out_data.Message_seq = (out_data.Message_seq * 16) + (uint16_t)f_i_Hex2Dec(Data[i]);
                case 3:
                    out_data.Message_size = (out_data.Message_size * 16) + (uint16_t)f_i_Hex2Dec(Data[i]);
            }
            Data_Num++;
            integer = 0;
        }
    }
    return out_data
}

int f_i_Hex2Dec(char data)
{
    int ret;
    if(48 <= (int)(data)  && (int)(data)  <= 57){
        ret = (int)(data) - 48;
    }else if(65 <= (int)(data)  && (int)(data)  <= 70)
    {
        ret = (int)(data) - 65 + 10;
    }else if(97 <= (int)(data)  && (int)(data)  <= 102)
    {
        ret = (int)(data)- 97 + 10;
    }
    return ret;
}


void* th_RelayServer_TcpIp_Task_Server(void *socket_info)
{
    int ret, i;
    struct socket_info_t *Socket_Info = (struct socket_info_t*)socket_info;
    struct sockaddr_in = Client_Address;
    socklen_t adr_sz = sizeof(clnt_adr);

    ret = listen(Socket_Info->Socket, 5);
    if(ret < 0)
    {
        F_RealyServer_Print_Debug(0,"[Error][%s][listen] Return Value:%d\n", ret);
        return;
    }
    pthread_mutex_init(&G_client_info.mtx, NULL);
    int epoll_size = 10;
    int epoll_event_count;
    struct epoll_event *epoll_events= malloc(sizeof(struct epoll_event)*epoll_size);

	int epfd = epoll_create(epoll_size);

	struct epoll_event epoll_event;
    epoll_event.events = EPOLLIN;
	epoll_event.data.fd = Socket_Info->Socket;	
	epoll_ctl(epfd, EPOLL_CTL_ADD, Socket_Info->Socket, &epoll_event);

    int str_len;
    int client_now;
    char *buf = malloc(BUF_SIZE);
    while(1)
    {
        epoll_event_count = epoll_wait(epfd, epoll_event, EPOLL_SIZE, -1);
		if(epoll_event_count == -1)
		{
			F_RealyServer_Print_Debug(0, "[Error][%s][epoll_wait() error]", __func__);
			break;
		}
		for(i = 0; i<epoll_event_count; i++)
		{
			if(epoll_events[i].data.fd == Socket_Info->Socket)
			{
				clnt_sock = accept(Socket_Info->Socket, (struct sockaddr*)&Client_Address, &adr_sz);
                if(clnt_sock > 0)
                {
                    pthread_mutex_lock(&G_client_info.mtx);
                    G_client_info.connected_client_num++;
                    G_client_info.socket[connected_client_num] = clnt_sock;
                    G_client_info.socket_message_seq [connected_client_num] = 0;
                    pthread_mutex_unlock(&G_client_info.mtx);
                    event.events = EPOLLIN;
                    event.data.fd = clnt_sock;
                    epoll_ctl(epfd, EPOLL_CTL_ADD, clnt_sock, &event);
                    F_RealyServer_Print_Debug(1,"[Sucess][%s] Client_Socket:%d\n", __func__, clnt_sock);
                }else{
                    F_RealyServer_Print_Debug(1,"[Error][%s] Return Value:%d\n", __func__, clnt_sock);
                }
			}
			else
			{
                str_len = read(epoll_events[i].data.fd, buf, BUF_SIZE);
                if(str_len > 0)
                {
                    pthread_mutex_lock(&G_client_info.mtx);
                    client_now = 0;
                    do{
                        client_now++
                        if(client_now  >= G_client_info.connected_client_num)
                        {
                            break;
                        }
                    }while(G_client_info.socket[client_now] != epoll_events[i].data.fd));
                    G_client_info.socket_message_seq[client_now]++;
                    sprintf(buf, "%01X%01X%02X%02X%02X%s",  //Client Data Protocol(Header:Hex_Sring,Payload:OCTETs)
                    0x0, //:job_state(1)
                    0x1, //protocol_type(1)
                    epoll_events[i].data.fd, //client_fd(2)
                    G_client_info.socket_message_seq[client_now], //message_seq(2);
                    str_len, buf);//message_size(2);data(payload_size)
                    size_t left_buf = F_i_Memory_Data_Push(Data_Info, (void *)buf, str_len + 8);
                    pthread_mutex_unlock(&G_client_info.mtx);
                    if(left_buf >= 0)
                    {
                        F_RealyServer_Print_Debug(2,"[Info][%s] Left_Buffer_Size:%d\n", __func__, left_buf);
                    }else{
                        F_RealyServer_Print_Debug(2,"[Error][%s] No left buffer:%d\n", __func__, left_buf);
                    }
                    
                }
            }
        }

    }
}

/* 
Brief:The Socket binding.
Parameter[In]
    Socket:Server Socket
    Socket_Addr:Server Socket Address
Parameter[Out]
    int 0 < Error_Code
 */
int f_i_RelayServer_TcpIp_Bind(int *Server_Socket, struct sockaddr_in Socket_Addr)
{
    int ret;
    int Retry_Max = 10;

    do
    {
        ret = bind(Server_Socket, (struct sockaddr*)&(Socket_Addr), sizeof(Socket_Addr));
        if(ret < 0 ) 
        {
            F_RealyServer_Print_Debug(0, "[Error][%s][Return_Value:%d]", __func__, ret);
            if(Retry_Count == 9)
            {
                close(Server_Socket);
                return -1;
            }
            Retry_Count++
        }else{
            char addr_str[40];
            inet_ntop(AF_INET, (void *)&Socket_Addr.sin_addr, addr_str, sizeof(addr_str));
            F_RealyServer_Print_Debug(1, "[Sucess][%s] 
            Server_Socket:%d;
            Ip:Port:%s:%d\n", 
             __func__, *Server_Socket, addr_str, Socket_Addr.sin_port);
            return 0;
        }
    }while(Retry_Count < 10);
        
}

/* 
Brief:Setting features of the Socket. The Timer set a socket block timer. The Linger set a socket remaining time after closing socket.
Parameter[In]
    Socket:socket
    Timer:socket block time
    Linger:socket remaining time
Parameter[Out]
    int 0 < Error_Code
 */
int f_i_RelayServer_TcpIp_Setup_Socket(int *Socket, int Timer, bool Linger)
{
    if(!Socket || Timer <= 0)
    {
        F_RealyServer_Print_Debug(0, "[Error][%s][No Input Argurements.](Socket:%p, Timer:%d)\n", __func__, Socket, Timer);
        return -1;
    }
    if(Linger)
    {
        struct linger solinger = { 1, 0 };  /* Socket FD close when the app down. */
        if (setsockopt(*Socket, SOL_SOCKET, SO_LINGER, &solinger, sizeof(struct linger)) == SO_ERROR) {
            perror("setsockopt(SO_LINGER)");
            return -3;
        }
    }

    if(Timer > 0)
    {
        struct timeval tv;                  /* Socket Connection End Timer */           
        tv.tv_sec = 0;
        tv.tv_usec = (Timer % 1000) * 1000; 
        if (setsockopt(*Socket, SOL_SOCKET, SO_RCVTIMEO, (struct timeval *)&tv,sizeof(struct timeval)) == SO_ERROR) {
            perror("setsockopt(SO_RCVTIMEO)");
            return -2;
        }
        if (setsockopt(*Socket, SOL_SOCKET, SO_SNDTIMEO, (struct timeval *)&tv,sizeof(struct timeval)) == SO_ERROR) {
            perror("setsockopt(SO_SNDTIMEO)");
            return -1;
        }
    }

}

/* 
Brief:According to the input debug level to print out a message in compare with the Global Debug Level.
Parameter[In]
    Debug_Lever_e:Debug Level
    String:A message to be print
    format:The Message Format
Parameter[Out]
    NULL
 */
void F_RealyServer_Print_Debug(enum debug_lever_e Debug_Level, const char *String, const char *format, ...)
{

  if(Debug_Level >= G_Debug_Level)
  {
    va_list arg;
    struct timespec ts;
    struct tm tm_now;

    clock_gettime(CLOCK_REALTIME, &ts);
    localtime_r((time_t *)&ts.tv_sec, &tm_now);
    fprintf(stderr, "[%04u%02u%02u.%02u%02u%02u.%06ld][%s] ", tm_now.tm_year+1900, tm_now.tm_mon+1, tm_now.tm_mday,
            tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec, ts.tv_nsec / 1000, String);

    va_start(arg, format);
    vprintf(format, arg);
    va_end(arg);
  }else{
    return;
  }
}

/* 
Brief:
Parameter[In]
Parameter[Out]
 */
void* Th_i_RelayServer_TickTimer(void *Data)
{
    Data = Data;
    int ret;
    int epoll_size = 1;
    int epoll_event_count;
    struct epoll_event *epoll_events= malloc(sizeof(struct epoll_event)*epoll_size);
    struct epoll_event epoll_event;
	int epfd = epoll_create(epoll_size);
    // Using_Timer
    int32_t TimerFd = timerfd_create(CLOCK_MONOTONIC, 0);
    struct itimerspec itval;
    struct timespec tv;
    uint32_t usec = 10 * 1000;
    uint64_t res;
    int mTime = 100;

    clock_gettime(CLOCK_MONOTONIC, &tv); 
    itval.it_interval.tv_sec = 0;
    itval.it_interval.tv_nsec = (usec % 1000000) * 1e3;
    itval.it_value.tv_sec = tv.tv_sec + 1;
    itval.it_value.tv_nsec = 0;
    ret = timerfd_settime (TimerFd, TFD_TIMER_ABSTIME, &itval, NULL);

    epoll_event.events = EPOLLIN;
	epoll_event.data.fd = TimerFd;	
	epoll_ctl(epfd, EPOLL_CTL_ADD, TimerFd, &epoll_event);

    uint32_t tick_count_10ms = 0;

    while(1)
    {   
        epoll_event_count = epoll_wait(epfd, epoll_events, epoll_size, -1);
        ret = recv(TimerFd, &res, sizeof(res), MSG_WAITALL);
        G_TickTimer.G_10ms_Tick = tick_count_10ms;
        switch(tick_count_10ms % 10)
        {
            case 0:
            {
                G_TickTimer.G_100ms_Tick++;
                break;
            }
            default: break;
        }
        switch(tick_count_10ms % 100)
        {
            case 0:
            {
                G_TickTimer.G_1000ms_Tick++;
                break;
            }
            default:break;
        }
        tick_count_10ms++;
    }
}

#if NOT_CODE_FINISH
void *t_RelayServer_GUI_Task_Run(int Update_Timer, struct socket_info_t *Socket_Info, struct clients_info_t *Client_Info)
{
    while(1)
    {
        system("clear");

        printf("*");printf("***************************************************************");printf("*\n");
        printf("*");printf("  SERVER INFOMATIONs                                           ");printf("*\n");
        printf("*");printf("  DEVICE_NAVE:%s IP/PORT:%s/%d                                 ",Socket_Info->Device_Name, Socket_Info->Device_IPv4_Address, Socket_Info->Port);printf("*\n");
        printf("*");printf("  CONNECTED CLIENT INFOMATION                                  ");printf("*\n");
        printf("*");printf("  CLIENT NUM:%d                                                ", Client_Info->connected_client_num);printf("*\n");
        printf("*");printf("  CLIENT LIST INFOMATION                                       ", Client_Info->connected_client_num);printf("*\n");
        for(client_count = 0; client_count < Client_Info->connected_client_num; client_count++)
        {
        printf("*");printf("  CLIENT_FD:%d CLIENT_IP: CLIENT_DATA_NUM:%d                                 ");printf("*\n");
        }
        printf("*");printf("***************************************************************");printf("*\n");
        sleep(Update_Timer);
        system("clear");
    }
}
#endif
// Job Source Code

enum payload_type_e
{
    Fireware,
    Program,
};

struct client_data_info_t 
{
    uint8_t ID[8];
    uint8_t Version[8];
    enum payload_type_e Payload_Type;
    size_t  Payload_Size;
};

struct data_header_info_t
{
    uint8_t Job_State;
    uint8_t Protocol_Type;
    uint16_t Client_fd;
    uint16_t Message_seq;
    uint16_t Message_size;
};

enum job_type_e{
    JobInitial,
    JobFinish,

    FirmwareInfoReport,
    FirmwareInfoRequest,
    FirmwareInfoResponse,
    FirmwareInfoIndication,
    FirmwareInfoResponseIndication,

    ProgramInfoReport,
    ProgramInfoRequest,
    ProgramInfoResponse,
    ProgramInfoIndication,
    ProgramInfoResponseIndication,

    HandOverReminingData
};

extern enum job_type_e F_e_RelayServer_Job_Process_Do(struct data_header_info_t *Now_Hader, uint8_t *Data, int Client_is);

static struct client_data_info_t f_s_RelayServer_Job_Process_JobInitial(struct data_header_info_t *Now_Hader, uint8_t *Data, int *err);
static int f_i_RelayServer_Job_Process_FirmwareInfoReport(struct data_header_info_t *Now_Hader, uint8_t *Data);
static int f_i_RelayServer_Job_Process_FirmwareInfoRequest(struct data_header_info_t *Now_Hader, uint8_t *Data);
static int f_i_RelayServer_Job_Process_FirmwareInfoResponse(struct data_header_info_t *Now_Hader, uint8_t *Data);
static int f_i_RelayServer_Job_Process_FirmwareInfoIndication(struct data_header_info_t *Now_Hader, uint8_t *Data);
static int f_i_RelayServer_Job_Process_JobFinish(struct data_header_info_t *Now_Hader, uint8_t *Data, int Client_is);

/* 
Brief:
Parameter[In]
Parameter[Out]
 */
enum job_type_e f_e_RelayServer_Job_Process_Do(struct data_header_info_t *Now_Hader, uint8_t *Data, int Client_is)
{
    int ret;
    enum job_type_e Now_Job_State = *Now_Hader.Job_State;
    enum job_type_e After_Job_State;
    
    switch(Now_Job_State)
    {
        case JobInitial:
            G_Client_Infos.client_data_info[Client_is] = f_s_RelayServer_Job_Process_JobInitial(Now_Hader, Data, &ret);
        case JobFinish:
            ret = f_i_RelayServer_Job_Process_JobFinish(Now_Hader, Data, Client_is);
        case FirmwareInfoReport:
        case ProgramInfoReport: 
            ret = f_e_RelayServer_Job_Process_FirmwareInfoReport(Now_Hader, Data);
            break;
        case FirmwareInfoRequest:
        case ProgramInfoRequest:
            ret = f_i_RelayServer_Job_Process_FirmwareInfoRequest(Now_Hader, Data);
            break;
        case FirmwareInfoResponse:
        case ProgramInfoResponse:
            ret = f_e_RelayServer_Job_Process_FirmwareInfoResponse(Now_Hader, Data);
            break;
        case FirmwareInfoIndication:
        case ProgramInfoIndication:
            ret = f_i_RelayServer_Job_Process_FirmwareInfoIndication(Now_Hader, Data);
            break;

        case HandOverReminingData:
            //f_s_RelayServer_Job_Process_HandOverReminingData()
            break;
        default:break;
    }
    if(ret > 0)
    {
        After_Job_State = Data[0];
    }
    if(Now_Job_State == After_Job_State)
    {
        
    }else{
        Now_Hader.Job_State = After_Job_State;
        G_Client_Infos.socket_job_state[Client_is] = After_Job_State;
    }

    return After_Job_State;
}

/* 
Brief:
Parameter[In]
    Now_Hader:
    Data:
    err:
Parameter[Out]
    client_data_info_t:It is made by the function 
 */
struct client_data_info_t f_s_RelayServer_Job_Process_JobInitial(struct data_header_info_t *Now_Hader, uint8_t *Data, int *err)
{
    if(Data)
    {
        char *Payload = (Data + HEADER_SIZE); 
        struct client_data_info_t out_data;
        if(Payload[0] == 0x44) // Check STX
        {
            switch((int)Payload[1])
            {
                case 1:
                    if(Now_Hader.Message_size > 18) //Will Make the Over Recv Error Solution
                    {

                    }
                    out_data.Payload_Type = Fireware;
                    Now_Hader->Job_State = 2;
                    Data[0] = "2";
                    break;
                case 3:
                    if(Now_Hader.Message_size > 18) //Will Make the Over Recv Error Solution
                    {

                    }
                    out_data.Payload_Type = Program;
                    Now_Hader->Job_State = 7;
                    Data[0] = "7";
                    break;
                default:
                    F_RealyServer_Print_Debug(0, "[Error][f_s_RelayServer_Job_Process_JobInitial][Payload_type:%d]", (int)Payload[1]);
                    *err = -1;
                    return 0;

            }
            memcpy(&(out_data.ID), Payload, 8);
            memcpy(&(out_data.Version), Payload + 8, 8);
        }
    }
    return out_data;
}

/* 
Brief:
Parameter[In]
    Now_Hader:
    Data:
    Client_is:
Parameter[Out]
    int 0 < Return Error Code
 */
int f_i_RelayServer_Job_Process_JobFinish(struct data_header_info_t *Now_Hader, uint8_t *Data, int Client_is)
{
    if(Data)
    {
        int ret;
        switch(Now_Hader->Job_State)
        {
            case JobFinish:
                memset(G_Clients_Info.client_data_info[Client_is].ID, 0x00, 8);
                memset(G_Clients_Info.client_data_info[Client_is].Version, 0x00, 8);
                G_Clients_Info.socket_message_seq[Client_is] = 0;
                G_Clients_Info.socket_job_state[Client_is] = 0;
                close(G_Clients_Info.socket[Client_is]);
                connected_client_num--;
            default:
                F_RealyServer_Print_Debug(0, "[Error][%s][Job_State:%d]", __func__, Now_Hader->Job_State);
                return -1;
        }
    }else{
        F_RealyServer_Print_Debug(0, "[Error][%s][No Data]\n", __func__);
        return -1;
    }
    return 0;
}

/* 
Brief:
Parameter[In]
    Now_Hader:
    Data:
Parameter[Out]
    int 0 < Return Error Code
 */
int f_i_RelayServer_Job_Process_FirmwareInfoReport(struct data_header_info_t *Now_Hader, uint8_t *Data)
{
    if(Data)
    {
        char *Payload = (Data + HEADER_SIZE); 
        if(Payload[0] == 0x44) // Check STX
        {
            switch(Now_Hader->Job_State)
            {
                case FirmwareInfoReport:
                    if(Now_Hader.Message_size == 18 && Payload[Now_Hader.Message_size] == 0xAA)
                    {
                        Now_Hader->Job_State = 3;
                        Data[0] = "3";
                        return Now_Hader->Job_State;
                    }else{
                        F_RealyServer_Print_Debug(0, "[Error][%s][Now_Hader.Message_size:%d, ETX:%02X]",__func__, Now_Hader.Message_size, Payload[Now_Hader.Message_size]);
                        return -3;
                    }
                    break;
                case ProgramInfoReport:
                    if(Now_Hader.Message_size == 18 && Payload[Now_Hader.Message_size] == 0xAA)
                    {
                        Now_Hader->Job_State = 8;
                        Data[0] = "8";
                        return Now_Hader->Job_State;
                    }else{
                        F_RealyServer_Print_Debug(0, "[Error][%s][Now_Hader.Message_size:%d, ETX:%02X]",__func__, Now_Hader.Message_size, Payload[Now_Hader.Message_size]);
                        return -8;
                    }
                default:
                    return 0;
            }     
        } 
    }else{
        F_RealyServer_Print_Debug(0, "[Error][%s][No Data]\n",__func__,);
        return -1;
    }
    return 0;
}

/* 
Brief:
Parameter[In]
    Now_Hader:
    Data:
    err:
Parameter[Out]
    client_data_info_t:It is made by the function 
 */
char f_i_RelayServer_Job_Process_FirmwareInfoRequest(struct data_header_info_t *Now_Hader, uint8_t *Data)
{
    if(Data)
    {
        switch(Now_Hader->Job_State)
        {
            case FirmwareInfoRequest:
                //Send the Data To PC_Server with HTTP Protocol
                Now_Hader->Job_State = 4;
                free(Data);
                char *out_data = malloc(sizeof(uint8_t) * HEADER_SIZE);
                sprintf(out_data, "%01X%01X%02X%02X%02X", 0x4, 0x0, Now_Hader->Client_fd, Now_Hader->Message_seq, 0x00);
                Data = out_data;
                break;
            case ProgramInfoRequest:
                //Send the Data To PC_Server with HTTP Protocol
                Now_Hader->Job_State = 9;
                free(Data);
                char *out_data = malloc(sizeof(uint8_t) * HEADER_SIZE);
                sprintf(out_data, "%01X%01X%02X%02X%02X", 0x4, 0x0, Now_Hader->Client_fd, Now_Hader->Message_seq, 0x00);
                Data = out_data;
            default:
                F_RealyServer_Print_Debug(0, "[Error][%s][Job_State:%d]", __func__, Now_Hader->Job_State);
                return -1;
        }     
    }else{
        F_RealyServer_Print_Debug(0, "[Error][%s][No Data]\n",__func__,);
        return -1;
    }
    return 0;
}

/* 
Brief:
Parameter[In]
    Now_Hader:
    Data:
    err:
Parameter[Out]
    client_data_info_t:It is made by the function 
 */
int f_i_RelayServer_Job_Process_FirmwareInfoResponse(struct data_header_info_t *Now_Hader, uint8_t *Data)
{
    if(Data)
    {
        switch(Now_Hader->Job_State)
        {
            case FirmwareInfoResponse:
                //Recv the Data From PC_Server with HTTP Protocol
                free(Data);
                char *out_data = malloc(sizeof(uint8_t) * (HEADER_SIZE + recv_data_size));
                Now_Hader->Job_State = 5;
                sprintf(out_data, "%01X%01X%02X%02X%02X", 0x5, 0x0, Now_Hader->Client_fd, Now_Hader->Message_seq, recv_data_size, recv_data);
                Data = out_data;
                break;
            case ProgramInfoResponse:
                //Recv the Data From PC_Server with HTTP Protocol
                free(Data);
                Now_Hader->Job_State = 0xA;
                char *out_data = malloc(sizeof(uint8_t) * (HEADER_SIZE + recv_data_size));
                sprintf(out_data, "%01X%01X%02X%02X%02X%s", 0xA, 0x0, Now_Hader->Client_fd, Now_Hader->Message_seq, recv_data_size, recv_data);
                Data = out_data;
                break;
            default:
                F_RealyServer_Print_Debug(0, "[Error][%s][Job_State:%d]", __func__, Now_Hader->Job_State);
                return -1;
        }
    }else{
        F_RealyServer_Print_Debug(0, "[Error][%s][No Data]\n",__func__,);
        return -1;
    }
    return 0;
}

/* 
Brief:
Parameter[In]
    Now_Hader:
    Data:
    err:
Parameter[Out]
    client_data_info_t:It is made by the function 
 */
int f_i_RelayServer_Job_Process_FirmwareInfoIndication(struct data_header_info_t *Now_Hader, uint8_t *Data)
{
    if(Data)
    {
        char *Payload = Data + HEADER_SIZE;
        int ret;
        switch(Now_Hader->Job_State)
        {
            case FirmwareInfoIndication:
            case ProgramInfoIndication:
                if(Now_Hader->Message_size <= 0)
                {
                    ret = send(ow_Hader->Client_fd, Payload, 20);
                    free(Data);
                    Now_Hader->Job_State = 1;
                    char *out_data = malloc(sizeof(uint8_t) * HEADER_SIZE);
                    sprintf(out_data, "%01X%01X%02X%02X%02X", 0x1, 0x0, Now_Hader->Client_fd, Now_Hader->Message_seq);
                    Data = out_data;
                    break;
                }else{
                    ret = send(ow_Hader->Client_fd, Payload, Now_Hader->Message_size);
                    free(Data);
                    Now_Hader->Job_State = 1;
                    char *out_data = malloc(sizeof(uint8_t) * HEADER_SIZE);
                    sprintf(out_data, "%01X%01X%02X%02X%02X", 0x1, 0x0, Now_Hader->Client_fd, Now_Hader->Message_seq);
                    Data = out_data;
                }
                break;
            default:
                F_RealyServer_Print_Debug(0, "[Error][%s][Job_State:%d]", __func__, Now_Hader->Job_State);
                return -1;
        }
    }else{
        F_RealyServer_Print_Debug(0, "[Error][%s][No Data]\n",__func__,);
        return -1;
    }
    return 0;
}

