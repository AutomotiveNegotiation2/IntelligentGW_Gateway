void main()
{
    return 0;
}